from django.contrib import admin
from .models import FAQ,ChatHistory

admin.site.register(FAQ)
admin.site.register(ChatHistory)
